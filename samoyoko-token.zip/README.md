# Samoyoko Token

Official metadata and logo for Samoyoko Token (SAYO).
